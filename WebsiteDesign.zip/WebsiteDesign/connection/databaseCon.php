<?php
 $localhost="127.0.0.1";
 $username= "root";
 $conn = new mysqli($localhost, $username);

	if ($conn-> connect_error) {
		die(" Connection failed: " . $conn->connect_error);
	}
	else {
		// echo "Connected successfully ";
		/*Create Databases */
		if ($conn->query("Create database IF NOT EXISTS employeeManagement") === TRUE) {
			// echo "Database created successfully <br>";
		} 
		else {			
			// if ($conn->query('use employeeManagement') === TRUE);
			// else echo "select any database "; 
			// echo "Error creating database: " . $conn->error;
		}
		/*End Databases */
	}

?>